﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
namespace Blood_Bank_Managemet_System
{
    public partial class AddPatient : Form
    {
        public AddPatient()
        {
            InitializeComponent();
        }
        Connection c = new Connection();
        Patient P = new Patient();

        private void AddPatient_Load(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void bunifuDatepicker1_onValueChanged(object sender, EventArgs e)
        {

        }

        private void TxtFname_TextChanged(object sender, EventArgs e)
        {

        }

        private void TxtLname_TextChanged(object sender, EventArgs e)
        {

        }

        private void DropdownBlood_onItemSelected(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            bunifuFlatButton2.Enabled = false;
            c.conn.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO Patient VALUES('"+TxtFname.Text.Trim()+ "','" + TxtLname.Text.Trim() + "','" + DropdownGender.selectedValue + "','" + TxtAge.Text.Trim() + "','" + TxtContact.Text.Trim() + "','" + Datepicker.Value+"','" + DropdownBlood.selectedValue+ "')", c.conn);
            cmd.ExecuteNonQuery();
            c.conn.Close();
            P.Show();
            this.Close();
            
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            bunifuFlatButton1.Enabled = false;
            this.Close();
            P.Show();

        }

        private void DropdownGender_onItemSelected(object sender, EventArgs e)
        {

        }

        private void TxtContact_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
