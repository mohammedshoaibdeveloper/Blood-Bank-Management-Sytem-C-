﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
namespace Blood_Bank_Managemet_System
{
    public partial class UpdateDoner : Form
    {
        Connection c = new Connection();
        DashBoard d = new DashBoard();
        public string uid;
        public string Fname;
        public string Lname;
        public string Age;
        public string Gender;
        public string Btype;
        public string Cnic;
        public string ContactNo;
        public string blood;
        public DateTime Date;
        public UpdateDoner()
        {
            InitializeComponent();
        }
        public int active;
        public string ubid;
        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            SqlCommand update = new SqlCommand("update Doner set FirstName='" + TxtFname.Text.Trim() + "', LastName='" + TxtLname.Text.Trim() + "', Age='" + TxtAge.Text.Trim() + "', Gender='" + DropdownGender.selectedValue.Trim() + "', CnicNo='" + TxtCnic.Text.Trim() + "' , ContactNO='" + TxtContact.Text.Trim() + "' , BID='" + DropdownBlood.selectedValue.Trim() + "' ,DonateDate='"+Datepicker.Value +"' where DID=@uid", c.conn);
            update.Parameters.AddWithValue("@uid", this.uid);
            c.conn.Open();

            update.ExecuteNonQuery();
            c.conn.Close();
            MessageBox.Show("Data his been updated");
            active = 1;
            bunifuFlatButton2.Enabled = false;
            
            this.Close();
            d.Show();
        }

        private void UpdateDoner_Load(object sender, EventArgs e)
        {
            TxtFname.Text = Fname;
            TxtLname.Text = Lname;
            TxtAge.Text = Age;
            TxtCnic.Text = Cnic;
            TxtContact.Text = ContactNo;
            Datepicker.Value = Date;
            if (Gender == "Male")
            {
                DropdownGender.selectedIndex = 0;
            }
            if (Gender == "Female")
            {
                DropdownGender.selectedIndex = 1;
            }
            
      if(Btype== "A+")
            {
                DropdownBlood.selectedIndex = 0;
            }
            if(Btype== "O+")
            {
                DropdownBlood.selectedIndex = 1;
            }
            if (Btype == "B+")
            {
                DropdownBlood.selectedIndex = 2;
            }

            if (Btype == "AB+")
            {
                DropdownBlood.selectedIndex = 3;
            }
            if (Btype == "A-")
            {
                DropdownBlood.selectedIndex = 4;
            }
            if (Btype == "O-")
            {
                DropdownBlood.selectedIndex = 5;
            }

            if (Btype == "B-")
            {
                DropdownBlood.selectedIndex = 6;
            }
            if (Btype == "AB-")
            {
                DropdownBlood.selectedIndex = 7;
            }
           
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            bunifuFlatButton1.Enabled = false;
            this.Close();
            d.Show();
        }

        private void DropdownBlood_onItemSelected(object sender, EventArgs e)
        {

        }

        private void DropdownGender_onItemSelected(object sender, EventArgs e)
        {

        }

        private void TxtLname_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
