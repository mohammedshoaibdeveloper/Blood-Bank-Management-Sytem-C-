﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Blood_Bank_Managemet_System
{
    public partial class AddDoner : Form
    {
        Connection c = new Connection();
        DashBoard dash = new DashBoard();
        
        public string bid;
        public AddDoner()
        {
            InitializeComponent();
        }
       
        private void AddDoner_Load(object sender, EventArgs e)
        {
             c.conn.Open();
            SqlCommand cmd = new SqlCommand("SELECT * FROM BloodType", c.conn);
            SqlDataReader dt;
            dt = cmd.ExecuteReader();


            if (dt.HasRows)
            {
                while (dt.Read())
                {
                  DropdownBlood.AddItem(dt[1].ToString());
                }
            }
            c.conn.Close();

        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            bunifuFlatButton1.Enabled = false;
            this.Close();
            dash.view();
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            c.conn.Close();
            c.conn.Open();
            
            SqlCommand insert = new SqlCommand("INSERT INTO Doner VALUES('"+TxtFname.Text+ "','" + TxtLname.Text + "','" + TxtAge.Text + "','" + DropdownGender.selectedValue + "','" +TxtCnic.Text + "','" + TxtContact.Text + "','" + bid + "' ,'"+Datepicker.Value+"')", c.conn);
            insert.ExecuteNonQuery();
            bunifuFlatButton2.Enabled = false;
         
            this.Close();
            dash.Show();
            c.conn.Close();
        }

        private void DropdownBlood_onItemSelected(object sender, EventArgs e)
        {
          
        }

        private void DropdownGender_onItemSelected(object sender, EventArgs e)
        {

        }

        private void TxtFname_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
