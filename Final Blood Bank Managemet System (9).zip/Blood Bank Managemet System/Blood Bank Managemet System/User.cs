﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
namespace Blood_Bank_Managemet_System
{
    public partial class User : Form
    {
        Connection c = new Connection();
        public string id;
        UpdateUser upuser = new UpdateUser();
        ViewUser vw = new ViewUser();
        public User()
        {
            InitializeComponent();
        }
        public void user()
        {
            try
            {
                c.conn.Open();
                SqlDataAdapter ad = new SqlDataAdapter("SELECT * FROM Users", c.conn);
                DataTable dt = new DataTable();
                ad.Fill(dt);
                if (dt.Rows.Count > 0)
                {



                    dt.Columns[0].ColumnName = "ID";
                    dt.Columns[1].ColumnName = "First Name";
                    dt.Columns[2].ColumnName = "Last Name";
                    dt.Columns[3].ColumnName = "Gender";
                    dt.Columns[4].ColumnName = "Contact NO";
                    dt.Columns[5].ColumnName = "User Name";
                    dt.Columns[6].ColumnName = "Password";
                    dt.Columns[7].ColumnName = "Role";
                    DataGrid1.DataSource = dt;
                    c.conn.Close();
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);


            }
            finally
            {

            }
        }

        private void BtnUser_Click(object sender, EventArgs e)
        {
         
        }

        private void BtnPatient_Click(object sender, EventArgs e)
        {
            Patient p = new Patient();
            p.Show();
            this.Hide();
        }

        private void btnDoner_Click(object sender, EventArgs e)
        {
            DashBoard d = new DashBoard();
            btnDoner.Enabled = false;
            this.Close();
            d.Show();

        }

        private void User_Load(object sender, EventArgs e)
        {
            user();

        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            Add_User adduser = new Add_User();
            bunifuFlatButton2.Enabled = false;
            this.Close();
            adduser.Show();

        }

        private void DataGrid1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                id = DataGrid1.SelectedRows[0].Cells[0].Value.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                
            }
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            try
            {
                if (id == null)
                {
                    MessageBox.Show("Row is Not Selected");

                }
                else
                {
                    c.conn.Open();
                    SqlCommand del = new SqlCommand("DELETE FROM Users WHERE UID=@id", c.conn);
                    del.Parameters.AddWithValue("@id", this.id);
                    del.ExecuteNonQuery();
                    c.conn.Close();
                    MessageBox.Show("The Data has been Deleted");
                    user();
                }

            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

        }

        private void bunifuFlatButton4_Click(object sender, EventArgs e)
        {
            try
            {
                if (id == null)
                {
                    MessageBox.Show("Please Select the Column");
                    Close();
                }
                else
                {
                    upuser.id = id;
                    upuser.Fname = DataGrid1.SelectedRows[0].Cells[1].Value.ToString();
                    upuser.Lname = DataGrid1.SelectedRows[0].Cells[2].Value.ToString();
                    upuser.Gender = DataGrid1.SelectedRows[0].Cells[3].Value.ToString();
                    upuser.ContactNo = DataGrid1.SelectedRows[0].Cells[4].Value.ToString();
                    upuser.UserName = DataGrid1.SelectedRows[0].Cells[5].Value.ToString();
                    upuser.pwd = DataGrid1.SelectedRows[0].Cells[6].Value.ToString();
                    upuser.role = DataGrid1.SelectedRows[0].Cells[7].Value.ToString();
                    bunifuFlatButton4.Enabled = false;
                    this.Hide();
                    upuser.Show();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void txtsearch_KeyUp(object sender, KeyEventArgs e)
        {
            string ser = txtsearch.Text;
            c.conn.Open();
            SqlDataAdapter search = new SqlDataAdapter("SELECT * FROM Users WHERE UFirstName LIKE '%" + ser + "%' or ULastName LIKE '%" + ser + "%' or  UGender LIKE '%" + ser + "%'  or UContactNO LIKE '%" + ser + "%' or UserName LIKE '%" + ser + "%' or  Role LIKE '%" + ser + "%'  or Password LIKE '%" + ser + "%' ", c.conn);
            DataTable dt = new DataTable();
            search.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                DataGrid1.DataSource = dt;
            }
            c.conn.Close();
        }

        private void bunifuImageButton1_Click(object sender, EventArgs e)
        {
            string ser = txtsearch.Text;
            c.conn.Open();
            SqlDataAdapter search = new SqlDataAdapter("SELECT * FROM Users WHERE UFirstName LIKE '%" + ser + "%' or ULastName LIKE '%" + ser + "%' or  UGender LIKE '%" + ser + "%'  or UContactNO LIKE '%" + ser + "%' or UserName LIKE '%" + ser + "%' or  Role LIKE '%" + ser + "%'  or Password LIKE '%" + ser + "%' ", c.conn);
            DataTable dt = new DataTable();
            search.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                DataGrid1.DataSource = dt;
            }
            else
            {
                MessageBox.Show("Record Not Found");
            }
            c.conn.Close();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
            try
            {
                if (id == null)
                {
                    MessageBox.Show("Please Select the Column");
                    Close();
                }
                else
                {
                    vw.id = id;
                    vw.Fname = DataGrid1.SelectedRows[0].Cells[1].Value.ToString();
                    vw.Lname = DataGrid1.SelectedRows[0].Cells[2].Value.ToString();
                    vw.Gender = DataGrid1.SelectedRows[0].Cells[3].Value.ToString();
                    vw.ContactNo = DataGrid1.SelectedRows[0].Cells[4].Value.ToString();
                    vw.UserName = DataGrid1.SelectedRows[0].Cells[5].Value.ToString();
                    vw.pwd = DataGrid1.SelectedRows[0].Cells[6].Value.ToString();
                    vw.role = DataGrid1.SelectedRows[0].Cells[7].Value.ToString();
                   
                   
                    vw.Show();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void bunifuFlatButton5_Click(object sender, EventArgs e)
        {
            Aboutus ub = new Aboutus();
            ub.Show();
        }
    }
}
