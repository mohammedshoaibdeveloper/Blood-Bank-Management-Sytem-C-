﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Blood_Bank_Managemet_System
{
    public partial class Patient_Update : Form
    {
        
      
        public Patient_Update()
        {
            InitializeComponent();
        }
        Connection c = new Connection();
        
        public string id;
        public string Fname;
        public string Lname;
        public string Gender;
        public string Age;
        public string ContactNo;
        public DateTime date;
        public string Btype;
        
        private void Patient_Update_Load(object sender, EventArgs e)
        {
            Datepicker.Value = date;
            TxtFname.Text = Fname;
            TxtLname.Text = Lname;
            TxtAge.Text = Age;
           TxtContact.Text = ContactNo;
            if (Gender == "Male")
            {
                DropdownGender.selectedIndex = 0;
            }
            if (Gender == "Female")
            {
                DropdownGender.selectedIndex = 1;
            }

            if (Btype == "A+")
            {
                DropdownBlood.selectedIndex = 0;
            }
            if (Btype == "O+")
            {
                DropdownBlood.selectedIndex = 1;
            }
            if (Btype == "B+")
            {
                DropdownBlood.selectedIndex = 2;
            }

            if (Btype == "AB+")
            {
                DropdownBlood.selectedIndex = 3;
            }
            if (Btype == "A-")
            {
                DropdownBlood.selectedIndex = 4;
            }
            if (Btype == "O-")
            {
                DropdownBlood.selectedIndex = 5;
            }

            if (Btype == "B-")
            {
                DropdownBlood.selectedIndex = 6;
            }
            if (Btype == "AB-")
            {
                DropdownBlood.selectedIndex = 7;
            }
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            Patient p = new Patient();
           
            SqlCommand update = new SqlCommand("update Patient set PFirstName='" + TxtFname.Text.Trim() + "', PLastName='" + TxtLname.Text.Trim() + "', PAge='" + TxtAge.Text.Trim() + "', PGender='" + DropdownGender.selectedValue.Trim() + "',PReciveDate='" + Datepicker.Value + "' , PContactNO='" + TxtContact.Text.Trim() + "' , PBID='" + DropdownBlood.selectedValue.Trim() + "' where PID=@id", c.conn);
            update.Parameters.AddWithValue("@id", this.id);
            c.conn.Open();
            update.ExecuteNonQuery();
            c.conn.Close();
         
            bunifuFlatButton2.Enabled = false;
            p.Show();
            this.Close();
           

        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            Patient p = new Patient();

            bunifuFlatButton1.Enabled = false;
            this.Close();
            p.Show();
        }

        private void TxtLname_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void Datepicker_onValueChanged(object sender, EventArgs e)
        {
            
        }
    }
}
