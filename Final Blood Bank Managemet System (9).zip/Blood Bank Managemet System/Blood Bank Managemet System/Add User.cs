﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
namespace Blood_Bank_Managemet_System
{
    public partial class Add_User : Form
    {
        public Add_User()
        {
            InitializeComponent();
        }
        Connection c = new Connection();
        User u = new User();
        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            c.conn.Open();
            SqlCommand cmd = new SqlCommand("INSERT INTO Users VALUES('"+TxtFname.Text.Trim()+ "','" + TxtLname.Text.Trim() + "','" + DropdownGender.selectedValue.Trim() + "','" + TxtContact.Text.Trim() + "','" + Txtuser.Text.Trim() + "','" + Txtpassword.Text.Trim() + "','" + Dropdownuser.selectedValue.Trim() + "')", c.conn);
            cmd.ExecuteNonQuery();
            c.conn.Close();
            bunifuFlatButton2.Enabled = false;
            this.Close();
            u.Show();

        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            bunifuFlatButton1.Enabled = false;
            this.Close();
            u.Show();
        }
    }
}
