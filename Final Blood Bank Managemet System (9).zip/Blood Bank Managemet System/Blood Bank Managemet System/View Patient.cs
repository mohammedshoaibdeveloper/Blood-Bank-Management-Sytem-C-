﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Blood_Bank_Managemet_System
{
    public partial class View_Patient : Form
    {
        public View_Patient()
        {
            InitializeComponent();
        }
        public string id;
        public string Fname;
        public string Lname;
        public string Gender;
        public string Age;
        public string ContactNo;
        public DateTime date;
        public string Btype;

        private void View_Patient_Load(object sender, EventArgs e)
        {
            lbFname.Text = Fname;
            lbLname.Text = Lname;
            LbAge.Text = Age;
            LbGender.Text = Gender;
            Lbcnic.Text = date.ToString();
            lbcontact.Text = ContactNo;
            lbblood.Text = Btype;
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
           
            Patient p = new Patient();
            bunifuFlatButton1.Enabled = false;
            p.Show();
            this.Close();
        }
    }
}
