﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Blood_Bank_Managemet_System
{
   
    public partial class Patient : Form
    {
        Connection c = new Connection();
        Patient_Update pupdate = new Patient_Update();
        View_Patient view = new View_Patient();
        DashBoard dash = new DashBoard();
        public string id;
        public string Roler;
        public Patient()
        {
            InitializeComponent();
        }
        private void patientview()
        {
            try
            {
                c.conn.Open();
                SqlDataAdapter query = new SqlDataAdapter("SELECT * FROM Patient ORDER BY PFirstName DESC", c.conn);
                DataTable dt = new DataTable();
                query.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    dt.Columns[0].ColumnName = "ID";
                    dt.Columns[1].ColumnName = "First Name";
                    dt.Columns[2].ColumnName = "Last Name";
                    dt.Columns[3].ColumnName = "Gender";
                    dt.Columns[4].ColumnName = "Age";
                    dt.Columns[5].ColumnName = "Contact No";
                    dt.Columns[6].ColumnName = "Date";
                    dt.Columns[7].ColumnName = "Blood Group";
                    DataGrid1.DataSource = dt;

                }
                c.conn.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
               
            }
        }
        private void Patient_Load(object sender, EventArgs e)
        {
            DropdownBlood.selectedIndex=0;
            Roler = dash.roe();
            if(Roler== "Receptionist")
            {
                bunifuFlatButton2.Hide();
                bunifuFlatButton1.Hide();
                bunifuFlatButton4.Hide();
                BtnUser.Hide();
            }
           if(Roler== "Lab Assistant")
            {
                BtnUser.Hide();
                bunifuFlatButton1.Hide();
            }

            patientview();

        }

        private void bunifuGradientPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void donergride_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            AddPatient addp = new AddPatient();
            bunifuFlatButton2.Enabled = false;
            addp.Show();
            this.Close();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnDoner_Click(object sender, EventArgs e)
        {
            DashBoard d = new DashBoard();
            btnDoner.Enabled = false;
            this.Close();
            d.Show();

        }

        private void DataGrid1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                id = DataGrid1.SelectedRows[0].Cells[0].Value.ToString();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                
            }            
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            try
            {
                bunifuFlatButton1.Enabled = false;

                if (id == null)
                {
                    MessageBox.Show("Row is Not Selected");

                }
                else
                {
                    SqlCommand del = new SqlCommand("DELETE FROM Patient WHERE PID=@id", c.conn);
                    del.Parameters.AddWithValue("@id", this.id);
                    c.conn.Open();
                    del.ExecuteNonQuery();
                    c.conn.Close();
                    patientview();
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void bunifuFlatButton4_Click(object sender, EventArgs e)
        {
            try
            {
                
                if (id == null)
                {
                    MessageBox.Show("Please Select the Column");
                   
                }
                else
                {
                    pupdate.id= id;
                    pupdate.Fname = DataGrid1.SelectedRows[0].Cells[1].Value.ToString();
                    pupdate.Lname = DataGrid1.SelectedRows[0].Cells[2].Value.ToString();
                    pupdate.Gender = DataGrid1.SelectedRows[0].Cells[3].Value.ToString();
                    pupdate.Age = DataGrid1.SelectedRows[0].Cells[4].Value.ToString();
                    pupdate.ContactNo = DataGrid1.SelectedRows[0].Cells[5].Value.ToString();
                    pupdate.date = Convert.ToDateTime(DataGrid1.SelectedRows[0].Cells[6].Value.ToString());
                    pupdate.Btype = DataGrid1.SelectedRows[0].Cells[7].Value.ToString();
                    pupdate.Show();
                    bunifuFlatButton4.Enabled = false;
                    this.Close();

                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void DataGrid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
            try
            {
                View_Patient view = new View_Patient();
                if (id == null)
                {
                    MessageBox.Show("Please Select the Column");
                
                }
                else
                {
                    view.id = id;
                    view.Fname = DataGrid1.SelectedRows[0].Cells[1].Value.ToString();
                    view.Lname = DataGrid1.SelectedRows[0].Cells[2].Value.ToString();
                    view.Gender = DataGrid1.SelectedRows[0].Cells[3].Value.ToString();
                    view.Age = DataGrid1.SelectedRows[0].Cells[4].Value.ToString();
                    view.ContactNo = DataGrid1.SelectedRows[0].Cells[5].Value.ToString();
                    view.date = Convert.ToDateTime(DataGrid1.SelectedRows[0].Cells[6].Value.ToString());
                    view.Btype = DataGrid1.SelectedRows[0].Cells[7].Value.ToString();
                    view.Show();
                    bunifuFlatButton3.Enabled = false;
                    



                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void txtsearch_KeyUp(object sender, KeyEventArgs e)
        {
            string ser = txtsearch.Text;
            c.conn.Open();
            SqlDataAdapter search = new SqlDataAdapter("SELECT * FROM Patient WHERE PFirstName LIKE '%" + ser + "%' or PLastName LIKE '%" + ser + "%' or PAge LIKE '%" + ser + "%' or PGender LIKE '%" + ser + "%' or PReciveDate LIKE '%" + ser + "%' or PContactNO LIKE '%" + ser + "%' or PBID LIKE '%" + ser + "%' ", c.conn);
            DataTable dt = new DataTable();
            search.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                DataGrid1.DataSource = dt;
            }
            
            c.conn.Close();
        }

        private void bunifuImageButton1_Click(object sender, EventArgs e)
        {
            string ser = txtsearch.Text;
            c.conn.Open();
            SqlDataAdapter search = new SqlDataAdapter("SELECT * FROM Patient WHERE PFirstName LIKE '%" + ser + "%' or PLastName LIKE '%" + ser + "%' or PAge LIKE '%" + ser + "%' or PGender LIKE '%" + ser + "%' or PReciveDate LIKE '%" + ser + "%' or PContactNO LIKE '%" + ser + "%' or PBID LIKE '%" + ser + "%' ", c.conn);
            DataTable dt = new DataTable();
            search.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                DataGrid1.DataSource = dt;
            }
            else
            {
                MessageBox.Show("Record Not Found");
            }
            c.conn.Close();
        }

        private void BtnUser_Click(object sender, EventArgs e)
        {
            User u = new User();
            BtnUser.Enabled = false;
            this.Hide();
            u.Show();
        }

        private void BtnPatient_Click(object sender, EventArgs e)
        {

        }

        private void DropdownBlood_onItemSelected(object sender, EventArgs e)
        {

            string ser = DropdownBlood.selectedValue;
            c.conn.Open();
            if (ser == "Blood Group")
            {
                ser = "";
            }

            SqlDataAdapter search = new SqlDataAdapter("SELECT * FROM DONER WHERE BID LIKE '%" + ser + "%' ", c.conn);
            DataTable dt = new DataTable();
            search.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                DataGrid1.DataSource = dt;
            }
            else
            {
                MessageBox.Show("Blood Group Not Found");
            }
            c.conn.Close();
        }

        private void bunifuFlatButton5_Click(object sender, EventArgs e)
        {
            Aboutus ub = new Aboutus();
            ub.Show();
        }
    }
}
