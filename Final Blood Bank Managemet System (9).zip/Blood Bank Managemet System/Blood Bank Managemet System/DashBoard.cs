﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;


namespace Blood_Bank_Managemet_System
{
    public partial class DashBoard : Form
    {
        Connection c = new Connection();
       
        public string id;
        public string Roler;
        public string bloodser;
        
        public DashBoard()
        {
          
            InitializeComponent();
        }
        public string roe() {
            string x;
            c.conn.Open();
            SqlDataAdapter cmd = new SqlDataAdapter("SELECT roler from Roler WHERE id=1", c.conn);
            DataTable dt = new DataTable();
            cmd.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                x = dt.Rows[0][0].ToString();
            }
            else
            {
                x = "not found";
            }
            c.conn.Close();
            return x;
           
        }
        public void view()
        {
            try
            {
                c.conn.Open();
                SqlDataAdapter ad = new SqlDataAdapter("SELECT * FROM Doner", c.conn);
                DataTable dt = new DataTable();
                ad.Fill(dt);
                if (dt.Rows.Count > 0)
                {

                
               
                    dt.Columns[0].ColumnName = "ID";
                    dt.Columns[1].ColumnName = "First Name";
                    dt.Columns[2].ColumnName = "Last Name";
                    dt.Columns[3].ColumnName = "Age";
                    dt.Columns[4].ColumnName = "Gender";
                    dt.Columns[5].ColumnName = "CNIC NUMBER";
                    dt.Columns[6].ColumnName = "Contact NO";
                    dt.Columns[5].ColumnName = "CNIC NUMBER";
                    dt.Columns[6].ColumnName = "BLOOD GROUP";

                  
                   
                 
                
                    DataGrid1.DataSource = dt;
                    c.conn.Close();
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);


            }
            finally
            {

            }
        }


        private void DashBoard_Load(object sender, EventArgs e)
        {
            Roler = roe();
            DropdownBlood.selectedIndex = 0;            

            UpdateDoner d = new UpdateDoner();
            view();
          if(Roler== "Receptionist")
            {
                bunifuFlatButton2.Hide();
                bunifuFlatButton1.Hide();
                bunifuFlatButton4.Hide();
                BtnUser.Hide();
            }
            if (Roler == "Lab Assistant")
            {
                BtnUser.Hide();
                bunifuFlatButton1.Hide();
            }
        }

        private void bunifuGradientPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuGradientPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            bunifuFlatButton1.Enabled = false;
            Patient p = new Patient();
            p.Show();
            this.Hide();
        }
        

        private void BtnDoner_click(object sender, EventArgs e)
        {
            
        }

        private void bunifuFlatButton4_Click(object sender, EventArgs e)
        {
            UpdateDoner udon = new UpdateDoner();

            try
            {
                if (id == null)
                {
                    MessageBox.Show("Please Select the Column");
                    Close();
                }
                else
                {
                    udon.uid = id;
                    udon.Fname = DataGrid1.SelectedRows[0].Cells[1].Value.ToString();
                    udon.Lname = DataGrid1.SelectedRows[0].Cells[2].Value.ToString();
                    udon.Age = DataGrid1.SelectedRows[0].Cells[3].Value.ToString();
                    udon.Gender = DataGrid1.SelectedRows[0].Cells[4].Value.ToString();
                    udon.Cnic = DataGrid1.SelectedRows[0].Cells[5].Value.ToString();
                    udon.ContactNo = DataGrid1.SelectedRows[0].Cells[6].Value.ToString();
                    udon.Btype = DataGrid1.SelectedRows[0].Cells[7].Value.ToString();
                    udon.Date = Convert.ToDateTime(DataGrid1.SelectedRows[0].Cells[8].Value);
                    this.Hide();
                    udon.Show();

                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
            
        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {

            Doner_Report udon = new Doner_Report();
            try
            {
                if (id == null)
                {
                    MessageBox.Show("Please Select the Column");
                   
                }
                else
                {
                    udon.uid = id;
                    udon.Fname = DataGrid1.SelectedRows[0].Cells[1].Value.ToString();
                    udon.Lname = DataGrid1.SelectedRows[0].Cells[2].Value.ToString();
                    udon.Age = DataGrid1.SelectedRows[0].Cells[3].Value.ToString();
                    udon.Gender = DataGrid1.SelectedRows[0].Cells[4].Value.ToString();
                    udon.Cnic = DataGrid1.SelectedRows[0].Cells[5].Value.ToString();
                    udon.ContactNo = DataGrid1.SelectedRows[0].Cells[6].Value.ToString();
                    udon.Btype = DataGrid1.SelectedRows[0].Cells[7].Value.ToString();
                    udon.Show();

                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }


        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            bunifuFlatButton2.Enabled = false;
            AddDoner addoner = new AddDoner();
            addoner.Show();
            this.Hide();
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void DataGrid1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                id = DataGrid1.SelectedRows[0].Cells[0].Value.ToString();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }           
           
        }

        private void bunifuFlatButton1_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (id == null)
                {
                    MessageBox.Show("Row is Not Selected");
                }
                else
                {
                    c.conn.Open();
                    SqlCommand del = new SqlCommand("delete from Doner Where DID=@id", c.conn);
                    del.Parameters.AddWithValue("@id", this.id);
                    del.ExecuteNonQuery();
                    c.conn.Close();
                    view();
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

          
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label5_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;

        }

        private void DashBoard_MouseMove(object sender, MouseEventArgs e)
        {
            
        }

        private void DataGrid1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void bunifuMetroTextbox1_OnValueChanged(object sender, EventArgs e)
        {

        }

        private void txtsearch_KeyUp(object sender, KeyEventArgs e)
        {
            string ser = txtsearch.Text;
            c.conn.Open();
            SqlDataAdapter search = new SqlDataAdapter("SELECT * FROM DONER WHERE FirstName LIKE '%" + ser + "%' or LastName LIKE '%" + ser + "%' or Age LIKE '%" + ser + "%' or Gender LIKE '%" + ser + "%' or CnicNo LIKE '%" + ser + "%' or ContactNO LIKE '%" + ser + "%' or DonateDate LIKE '%" + ser + "%' or BID LIKE '%" + ser + "%'", c.conn);
            DataTable dt = new DataTable();
            search.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                DataGrid1.DataSource = dt;
            }
            c.conn.Close();
        }

        private void bunifuImageButton1_Click(object sender, EventArgs e)
        {
            string ser = txtsearch.Text;
            c.conn.Open();
            SqlDataAdapter search = new SqlDataAdapter("SELECT * FROM DONER WHERE FirstName LIKE '%" + ser + "%' or LastName LIKE '%" + ser + "%' or Age LIKE '%" + ser + "%' or Gender LIKE '%" + ser + "%' or CnicNo LIKE '%" + ser + "%' or ContactNO LIKE '%" + ser + "%' or DonateDate LIKE '%" + ser + "%' or BID LIKE '%" + ser + "%'", c.conn);
            DataTable dt = new DataTable();
            search.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                DataGrid1.DataSource = dt;
            }
            else
            {
                MessageBox.Show("Records Not found");
            }
            c.conn.Close();
        }

        private void DropdownBlood_onItemSelected(object sender, EventArgs e)
        {

        }

        private void Datepicker_onValueChanged(object sender, EventArgs e)
        {

        }

        private void DropdownBlood_onItemSelected_1(object sender, EventArgs e)
        {
            string ser = DropdownBlood.selectedValue;
            c.conn.Open();
            if (ser == "Blood Group")
            {
                ser = "";
            }

            SqlDataAdapter search = new SqlDataAdapter("SELECT * FROM DONER WHERE BID LIKE '%" + ser + "%' ", c.conn);

            DataTable dt = new DataTable();
            search.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                DataGrid1.DataSource = dt;
            }
            else
            {
                MessageBox.Show("Blood Group Not Found");
            }
            c.conn.Close();
        }

        private void bunifuFlatButton5_Click(object sender, EventArgs e)
        {
            Aboutus ub = new Aboutus();
            ub.Show();
        }
    }
}
