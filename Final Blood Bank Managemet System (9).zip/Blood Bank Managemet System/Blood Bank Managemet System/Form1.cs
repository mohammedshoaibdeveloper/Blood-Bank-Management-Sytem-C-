﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Blood_Bank_Managemet_System
{
    public partial class Form1 : Form
    {
        Connection c = new Connection();
        public Form1()
        {
            InitializeComponent();
        }
        public string Roler;
        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }




        private void label1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            c.conn.Open();
            SqlCommand rol = new SqlCommand("UPDATE Roler SET roler='Receptionist' WHERE id=1", c.conn);
            rol.ExecuteNonQuery();
            c.conn.Close();
        }



        private void button1_Click(object sender, EventArgs e)
        {
            DashBoard dash = new DashBoard();
            c.conn.Open();
            SqlDataAdapter query = new SqlDataAdapter("SELECT * FROM Users WHERE UserName='" + textBox1.Text + "' AND Password='" + textBox2.Text + "'", c.conn);
            DataTable dt = new DataTable();
            query.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                // Admin Access
                if (dt.Rows[0][7].ToString()=="Admin" && radioAdmin.Checked)
                {
                    Roler = dt.Rows[0][7].ToString();
                    this.Hide();
                    dash.Show();
                }
                // Lab Assistant Access
                else if (dt.Rows[0][7].ToString() == "Lab Assistant" && radioLab.Checked)
                {

                    Roler = dt.Rows[0][7].ToString();
                    this.Hide();
                    dash.Show();
                }
                                // Lab Assistant Access
               else if (dt.Rows[0][7].ToString() == "Receptionist" && radioRecp.Checked)
                {

                    Roler = dt.Rows[0][7].ToString();
                    this.Hide();
                    dash.Show();
                }
                else
                {
                    MessageBox.Show("Please Select the user Role");
                }
            }
            else
            {
                MessageBox.Show("Please Enter Correct User Name and Password");
            }
         
        
            c.conn.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioAdmin_CheckedChanged(object sender, EventArgs e)
        {
            c.conn.Open();
            SqlCommand rol = new SqlCommand("UPDATE Roler SET roler='Admin' WHERE id=1", c.conn);
            rol.ExecuteNonQuery();
            c.conn.Close();
        }

        private void radioLab_CheckedChanged(object sender, EventArgs e)
        {
            c.conn.Open();
            SqlCommand rol = new SqlCommand("UPDATE Roler SET roler='Lab Assistant' WHERE id=1", c.conn);
            rol.ExecuteNonQuery();
            c.conn.Close();
        }
    }
}
