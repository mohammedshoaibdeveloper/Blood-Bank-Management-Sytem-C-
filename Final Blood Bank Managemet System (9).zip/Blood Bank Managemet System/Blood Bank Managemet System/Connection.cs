﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data.SqlClient;


namespace Blood_Bank_Managemet_System
{
    class Connection
    {
        public SqlConnection conn = new SqlConnection(@"Data Source=SHOAIBGHULAM-PC\SQLEXPRESS;Initial Catalog=BloodBank;Integrated Security=True");
        
    }
}
