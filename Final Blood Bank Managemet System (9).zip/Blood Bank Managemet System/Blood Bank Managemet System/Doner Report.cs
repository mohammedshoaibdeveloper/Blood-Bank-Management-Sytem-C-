﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Blood_Bank_Managemet_System
{
    public partial class Doner_Report : Form
    {
        public Doner_Report()
        {
            InitializeComponent();
        }
        Connection c = new Connection();
        DashBoard d = new DashBoard();
        public string uid;
        public string Fname;
        public string Lname;
        public string Age;
        public string Gender;
        public string Btype;
        public string Cnic;
        public string ContactNo;
        public string blood;
        private void Doner_Report_Load(object sender, EventArgs e)
        {
           
            lbFname.Text = Fname;
            lbLname.Text = Lname;
            LbAge.Text = Age;
            LbGender.Text = Gender;
            Lbcnic.Text = Cnic;
            lbcontact.Text = ContactNo;
           lbblood.Text =Btype;
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            bunifuFlatButton1.Enabled = false;
            this.Close();
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {

        }
    }
}
