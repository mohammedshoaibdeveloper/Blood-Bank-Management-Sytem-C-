﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
namespace Blood_Bank_Managemet_System
{
    public partial class UpdateUser : Form
    {
        Connection c = new Connection();
      
        public UpdateUser()
        {
            InitializeComponent();
        }
        public string id;
        public string Fname;
        public string Lname;
        public string Gender;
        public string ContactNo;
        public string UserName;
        public string pwd;
        public string role;
        private void UpdateUser_Load(object sender, EventArgs e)
        {
            TxtFname.Text = Fname;
            TxtLname.Text = Lname;
            TxtContact.Text = ContactNo;
            Txtuser.Text = UserName;
            Txtpassword.Text = pwd;
            if (Gender== "Male")
            {
                DropdownGender.selectedIndex = 0;
            }
            if (Gender == "FeMale")
            {
                DropdownGender.selectedIndex = 1;
            }
            


            if (role == "Admin")
            {
                Dropdownuser.selectedIndex = 0;
            }
            if(role== "Lab Assistant")
            {
                Dropdownuser.selectedIndex = 1;
            }
            if (role == "Receptionist")
            {
                Dropdownuser.selectedIndex = 2;
            }

        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            User u = new User();
            c.conn.Open();
            SqlCommand cmd= new SqlCommand("UPDATE Users SET UFirstName='" + TxtFname.Text.Trim() + "', ULastName='" + TxtLname.Text.Trim() + "', UGender='" + DropdownGender.selectedValue+ "', UContactNo='" + TxtContact.Text.Trim() + "', UserName='" + Txtuser.Text.Trim() + "', Password='" + Txtpassword.Text.Trim() + "', Role='" + Dropdownuser.selectedValue.Trim()+ "' WHERE UID=@id", c.conn);
            cmd.Parameters.AddWithValue("@id", this.id);
            cmd.ExecuteNonQuery();
            c.conn.Close();
            bunifuFlatButton2.Enabled = false;
            this.Close();
            u.Show();
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            User u = new User();
            bunifuFlatButton1.Enabled = false;
            this.Close();
            u.Show();
        }

        private void TxtFname_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
