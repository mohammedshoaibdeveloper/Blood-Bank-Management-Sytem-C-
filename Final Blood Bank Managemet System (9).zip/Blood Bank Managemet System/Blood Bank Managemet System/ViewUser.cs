﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Blood_Bank_Managemet_System
{
    public partial class ViewUser : Form
    {
        public ViewUser()
        {
            InitializeComponent();
        }
        public string id;
        public string Fname;
        public string Lname;
        public string Gender;
        public string ContactNo;
        public string UserName;
        public string pwd;
        public string role;
        private void ViewUser_Load(object sender, EventArgs e)
        {
            lbFname.Text = Fname;
            lbLname.Text = Lname;
            LbGender.Text = Gender;
            lbcontact.Text = ContactNo;
            Lbuser.Text = UserName;
            lbpass.Text = pwd;
            lbRole.Text = role;

        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            this.Close();
            bunifuFlatButton1.Enabled = false;
        }
    }
}
